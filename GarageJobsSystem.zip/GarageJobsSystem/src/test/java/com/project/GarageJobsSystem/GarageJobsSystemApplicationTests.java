package com.project.GarageJobsSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GarageJobsSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
